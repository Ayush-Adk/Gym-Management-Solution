﻿namespace GymManagement.Models
{
    public enum DOW
    {
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday
    }
}
