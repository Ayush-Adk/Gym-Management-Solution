﻿namespace GymManagement.ViewModels
{
    public class ListOptionVM
    {
        public int ID { get; set; }
        public string DisplayText { get; set; } = "";
    }
}
